import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report
from sklearn.utils.class_weight import compute_class_weight
import joblib

#  dataset
df = pd.read_csv('dataset.csv')

# Feature engineering
df['performance_ratio'] = df['exam_score'] / df['attendance_percentage']
df['attendance_score_combo'] = df['attendance_percentage'] * 0.4 + df['exam_score'] * 0.6

# Encode  variables
gender_encoder = LabelEncoder()
education_encoder = LabelEncoder()
level_encoder = LabelEncoder()

df['gender_encoded'] = gender_encoder.fit_transform(df['gender'])
df['education_encoded'] = education_encoder.fit_transform(df['previous_education'])
df['level_encoded'] = level_encoder.fit_transform(df['level'])

# Define features and target
features = ['age', 'gender_encoded', 'education_encoded', 'study_hours_weekly',
            'attendance_percentage', 'exam_score', 'performance_ratio', 'attendance_score_combo']
X = df[features]
y = df['level_encoded']

# Handle imbalance
classes = np.unique(y)
weights = compute_class_weight('balanced', classes=classes, y=y)
class_weights = dict(zip(classes, weights))

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, stratify=y, random_state=42
)

# GridSearchCV
param_grid = {
    'n_estimators': [50, 100],
    'max_depth': [None, 5],
    'min_samples_split': [2, 5],
    'min_samples_leaf': [1, 2],
    'class_weight': [None, 'balanced', class_weights]
}

model = RandomForestClassifier(random_state=42)
grid_search = GridSearchCV(model, param_grid, cv=3, scoring='accuracy')
grid_search.fit(X_train, y_train)
best_model = grid_search.best_estimator_

# Evaluation
y_pred = best_model.predict(X_test)
print("Best Parameters:", grid_search.best_params_)
print("\nClassification Report:\n", classification_report(y_test, y_pred, target_names=level_encoder.classes_))

# Feature importances
print("\nFeature Importances:")
for feature, importance in zip(features, best_model.feature_importances_):
    print(f"{feature}: {importance:.4f}")

# Save
joblib.dump(best_model, 'best_model.pkl')
joblib.dump(gender_encoder, 'gender_encoder.pkl')
joblib.dump(education_encoder, 'education_encoder.pkl')
joblib.dump(level_encoder, 'level_encoder.pkl')
