import joblib
import openai
import json
from getpass import getpass

#  saved model
model = joblib.load('best_model.pkl')
gender_encoder = joblib.load('gender_encoder.pkl')
education_encoder = joblib.load('education_encoder.pkl')
level_encoder = joblib.load('level_encoder.pkl')


def predict_student_level(age, gender, previous_education, study_hours_weekly, attendance, exam_score):
    gender_encoded = gender_encoder.transform([gender])[0]
    education_encoded = education_encoder.transform([previous_education])[0]
    performance_ratio = exam_score / attendance
    attendance_score_combo = attendance * 0.4 + exam_score * 0.6

    input_data = [[age, gender_encoded, education_encoded, study_hours_weekly,
                   attendance, exam_score, performance_ratio, attendance_score_combo]]

    pred = model.predict(input_data)
    return level_encoder.inverse_transform(pred)[0]


def run_quiz():

    openai.api_key = "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"

    #  prediction inputs
    result = predict_student_level(

        12,
        'Female',
        'Basic',
        10,
        85,
        75)

    print("Predicted Level:", result)

    prompt = (
        f"Generate 5 multiple-choice questions about Sri Lankan history appropriate for a student at level: {result}. "
        "Each question must have 4 options labeled A, B, C, D with one correct answer. "
        "Format the output as a JSON list where each element is a dictionary with: "
        "{'question': 'text', 'options': {'A': 'text', 'B': 'text', 'C': 'text', 'D': 'text'}, 'answer': 'letter'}. "
        "The questions should match the student's predicted comprehension level - "
        "use simpler concepts and language for lower levels, more advanced for higher levels."
    )

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=600
        )

        content = response['choices'][0]['message']['content']
        questions = json.loads(content)

        print("\nWelcome to the Sri Lankan History Quiz!\n")
        score = 0

        for idx, q in enumerate(questions, 1):
            print(f"Q{idx}. {q['question']}")
            for opt_key, opt_text in q['options'].items():
                print(f"   {opt_key}. {opt_text}")
            answer = input("Your answer (A/B/C/D): ").strip().upper()
            if answer == q['answer'].upper():
                print("Correct!\n")
                score += 1
            else:
                print(f"Incorrect. Correct answer: {q['answer']}\n")

        print(f"You scored {score} out of {len(questions)}")

    except json.JSONDecodeError:
        print("Error: Could not parse the questions. Raw response:")
        print(content)
    except Exception as e:
        print("Error occurred:", e)

if __name__ == "__main__":
    run_quiz()