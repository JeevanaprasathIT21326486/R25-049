import joblib

# Load saved model
model = joblib.load('best_model.pkl')
gender_encoder = joblib.load('gender_encoder.pkl')
education_encoder = joblib.load('education_encoder.pkl')
level_encoder = joblib.load('level_encoder.pkl')

def predict_student_level(age, gender, previous_education, study_hours_weekly, attendance, exam_score):
    gender_encoded = gender_encoder.transform([gender])[0]
    education_encoded = education_encoder.transform([previous_education])[0]
    performance_ratio = exam_score / attendance
    attendance_score_combo = attendance * 0.4 + exam_score * 0.6

    input_data = [[age, gender_encoded, education_encoded, study_hours_weekly,
                   attendance, exam_score, performance_ratio, attendance_score_combo]]

    pred = model.predict(input_data)
    return level_encoder.inverse_transform(pred)[0]

#  input
if __name__ == "__main__":
    result = predict_student_level(12, 'Female', 'Basic', 10, 85, 75)
    print("Predicted Level:", result)
