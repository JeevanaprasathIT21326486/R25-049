from flask import Flask, request, jsonify
import joblib
import openai
import json
import os
from dotenv import load_dotenv


load_dotenv()

app = Flask(__name__)


model = joblib.load('best_model.pkl')
gender_encoder = joblib.load('gender_encoder.pkl')
education_encoder = joblib.load('education_encoder.pkl')
level_encoder = joblib.load('level_encoder.pkl')


openai.api_key = os.getenv('OPENAI_API_KEY')


def predict_student_level(age, gender, previous_education, study_hours_weekly, attendance, exam_score):
    try:
        gender_encoded = gender_encoder.transform([gender])[0]
        education_encoded = education_encoder.transform([previous_education])[0]
        performance_ratio = exam_score / attendance
        attendance_score_combo = attendance * 0.4 + exam_score * 0.6

        input_data = [[age, gender_encoded, education_encoded, study_hours_weekly,
                       attendance, exam_score, performance_ratio, attendance_score_combo]]

        pred = model.predict(input_data)
        return level_encoder.inverse_transform(pred)[0]
    except Exception as e:
        raise ValueError(f"Prediction error: {str(e)}")


@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()

        # Validate input data
        required_fields = ['age', 'gender', 'previous_education',
                           'study_hours_weekly', 'attendance', 'exam_score']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400

        result = predict_student_level(
            data['age'],
            data['gender'],
            data['previous_education'],
            data['study_hours_weekly'],
            data['attendance'],
            data['exam_score']
        )

        return jsonify({
            'predicted_level': result,
            'status': 'success'
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/generate-quiz', methods=['POST'])
def generate_quiz():
    try:
        data = request.get_json()


        if 'student_data' in data:
            student_data = data['student_data']
            result = predict_student_level(
                student_data['age'],
                student_data['gender'],
                student_data['previous_education'],
                student_data['study_hours_weekly'],
                student_data['attendance'],
                student_data['exam_score']
            )
        # Option 2: Get level directly
        elif 'level' in data:
            result = data['level']
        else:
            return jsonify({'error': 'Must provide either student_data or level'}), 400

        prompt = (
            f"Generate 5 multiple-choice questions about Sri Lankan history appropriate for a student at level: {result}. "
            "Each question must have 4 options labeled A, B, C, D with one correct answer. "
            "Format the output as a JSON list where each element is a dictionary with: "
            "{'question': 'text', 'options': {'A': 'text', 'B': 'text', 'C': 'text', 'D': 'text'}, 'answer': 'letter'}. "
            "The questions should match the student's predicted comprehension level - "
            "use simpler concepts and language for lower levels, more advanced for higher levels."
        )

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=600
        )

        content = response['choices'][0]['message']['content']
        questions = json.loads(content)

        return jsonify({
            'questions': questions,
            'level': result,
            'status': 'success'
        })

    except json.JSONDecodeError:
        return jsonify({
            'error': 'Failed to parse quiz questions',
            'raw_response': content
        }), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/check-answers', methods=['POST'])
def check_answers():
    try:
        data = request.get_json()

        if 'questions' not in data or 'answers' not in data:
            return jsonify({'error': 'Missing questions or answers in request'}), 400

        if len(data['questions']) != len(data['answers']):
            return jsonify({'error': 'Number of questions and answers must match'}), 400

        score = 0
        results = []

        for q, user_answer in zip(data['questions'], data['answers']):
            correct = q['answer'].upper() == user_answer.upper()
            if correct:
                score += 1
            results.append({
                'question': q['question'],
                'correct_answer': q['answer'],
                'user_answer': user_answer,
                'is_correct': correct
            })

        return jsonify({
            'score': score,
            'total_questions': len(data['questions']),
            'results': results,
            'status': 'success'
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)