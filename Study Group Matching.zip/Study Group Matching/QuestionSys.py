import openai

# Initialize OpenAI API (store securely in a real application)
openai.api_key = "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"

# Prompt to generate 5 MCQs on Sri Lankan history
prompt = (
    "Generate 5 multiple-choice questions related to the history of Sri Lanka. "
    "Each question must have 4 options labeled A, B, C, D. Also, provide the correct answer letter for each question. "
    "Format the output as a list of dictionaries with 'question', 'options', and 'answer' keys."
)

try:
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=600
    )

    import json

    content = response['choices'][0]['message']['content']
    
    # Try to parse the returned content as Python list using eval or json.loads
    try:
        # If the model returns a Python list as string, use eval
        questions = eval(content)
    except:
        # In case it's JSON-like, try json.loads
        questions = json.loads(content)

    print("\nWelcome to the Sri Lankan History Quiz!\n")
    score = 0

    for idx, q in enumerate(questions, 1):
        print(f"Q{idx}. {q['question']}")
        for opt_key, opt_text in q['options'].items():
            print(f"   {opt_key}. {opt_text}")
        answer = input("Your answer (A/B/C/D): ").strip().upper()
        if answer == q['answer'].upper():
            print("Correct!\n")
            score += 1
        else:
            print(f"Incorrect. Correct answer: {q['answer']}\n")

    print(f"You scored {score} out of {len(questions)}")

except Exception as e:
    print("Error occurred:", e)
